class estudiante:
    def __init__(self,carnet,dpi,nombre,carrera,correo,password,edad):
        self.carnet=carnet
        self.dpi=dpi
        self.nombre=nombre
        self.carrera=carrera
        self.correo=correo
        self.password=password
        self.edad=edad

    def getCarnet(self):
        return self.carnet

    def getDpi(self):
        return self.dpi
    
    def getNombre(self):
        return self.nombre
    
    def getCarrera(self):
        return self.carrera
    
    def getCorreo(self):
        return self.correo
    
    def getPassword(self):
        return self.password

    def getEdad(self):
        return self.edad

    def setCarnet(self,carnet):
        self.carnet=carnet

    def setDpi(self,dpi):
        self.dpi=dpi

    def setNombre(self,nombre):
        self.nombre=nombre

    def setCarrera(self,carrera):
        self.carrera=carrera

    def setCorrreo(self,correo):
        self.correo=correo

    def setPassword(self,password):
        self.password=password

    def setEdad(self,edad):
        self.edad=edad
