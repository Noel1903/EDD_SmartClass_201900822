from cursosP import Cursos
import os
pensum=Cursos()
class nodo_graph:
    def __init__(self,codigo,creditos):
        self.codigo=codigo
        self.creditos=creditos
        self.next=None

class list_graph:
    def __init__(self):
        self.head=None
        self.body=None
        

    def insert_node(self,codigo,creditos):
        nuevo=nodo_graph(codigo,creditos)
        if self.head==None:
            self.head=nuevo
            self.body=nuevo
        else:
            nodo=self.head
            while nodo:
                if nodo.codigo==codigo:
                    return
                nodo=nodo.next
            if nodo==None:
                self.body.next=nuevo
                self.body=nuevo

    def mostrar(self):
        nodo=self.head
        while nodo:
            print(nodo.codigo+" - "+str(nodo.creditos),end="------>\n")
            nodo=nodo.next

    def prerequisitos(self):
        nodo=self.head
        arr=[]
        while nodo:
            arr.append([nodo.codigo,nodo.creditos])
            nodo=nodo.next
        return arr

class node_list:
    def __init__(self,curso,nombre):
        self.curso=curso
        self.nombre=nombre
        self.list=list_graph()
        self.down=None
        
class list_:
    def __init__(self):
        self.head=None
        self.body=None
        self.reporte=""

    def insert_list(self,curso,nombre,codigo,creditos):
    
        nuevo=node_list(curso,nombre)
        if self.head==None:
            self.head=nuevo           
            self.head.list.insert_node(codigo,creditos)
            self.body=nuevo             
            self.body.list.insert_node(codigo,creditos)

        else:
            nodo=self.body
            while nodo:
                if nodo.curso==curso:
        
                    nodo.list.insert_node(codigo,creditos)
                    break
                nodo=nodo.down

            if nodo==None:

                nuevo.down=self.body
                self.body=nuevo
                self.body.list.insert_node(codigo,creditos)
            
    def existe(self,curso):
        nodo=self.body
        while nodo:
            if nodo.curso==curso:
                return True
            nodo=nodo.down
                
    def imprimir(self):
        nodo=self.body
        while nodo:
            print("Curso: "+nodo.curso+ "  Prerequisitos:")
            nodo.list.mostrar()
            nodo=nodo.down

    def graficar(self,curso):
        nodo=self.body

        while nodo:
            
            if nodo.curso==curso:
                self.reporte+=nodo.curso+"[label=\"Codigo: "+nodo.curso+"\\nNombre: "+nodo.nombre+"\"];\n"
                arr=nodo.list.prerequisitos()
                for i in arr:
                    if i[1]!=None:
                        self.reporte+=curso+"->"+i[0]+"[label=\""+str(i[1])+"\"]\n"
                    self.graficar(i[0])
                return
            
            nodo=nodo.down
        
    def graficarPensum(self):
        nodo=self.body
        reporte=""
        while nodo:
            reporte+=nodo.curso+"[label=\"Codigo: "+nodo.curso+"\\nNombre: "+nodo.nombre+"\"];\n"
            arr=nodo.list.prerequisitos()
            for i in arr:
                if i[1]!=None:
                    reporte+=nodo.curso+"->"+i[0]+"[label=\""+str(i[1])+"\"]\n"
                
                        
            nodo=nodo.down
        
        estructura="digraph G {\nrankdir=RL \nedge[arrowhead=none]\nnode[shape=box]\n"+reporte+" }"     
        documento=open("Pensum.dot","w",encoding="utf-8")
        documento.write(estructura)
        documento.close()
        os.system("dot -Tpng Pensum.dot -o Pensum.png")
        os.startfile("Pensum.png")

     
        
    def crearDocumento(self):
        estructura="digraph G {\nrankdir=RL \nedge[arrowhead=none]\nnode[shape=box]\n"+self.reporte+" }"     
        documento=open("prerequisitos.dot","w",encoding="utf-8")
        documento.write(estructura)
        documento.close()
        os.system("dot -Tpng prerequisitos.dot -o prerequisitos.png")
        os.startfile("prerequisitos.png")
        self.body=""
    
    



        