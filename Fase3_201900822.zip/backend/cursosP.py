
class nodo:
    def __init__(self,codigo,nombre,creditos,prerequisitos,obligatorio):
        self.codigo=codigo
        self.nombre=nombre
        self.creditos=creditos
        self.prerequisitos=prerequisitos
        self.obligatorio=obligatorio
        self.next=None
        self.previous=None
        

class Cursos:
    def __init__(self):
        self.head=None
        self.body=None
        self.lista=[]


    def insertar(self,codigo,nombre,creditos,prerequisitos,obligatorio):
        prereq=prerequisitos.split(",")
        nuevo=nodo(codigo,nombre,creditos,prereq,obligatorio)
        if self.head==None:
            self.head=nuevo
            self.body=nuevo

        else:
            nuevo.previous=self.body
            self.body.next=nuevo
            self.body=nuevo

    def devolverCursos(self):
        cursos=[]
        nodo=self.head
        while nodo:
            cursos.append(nodo.codigo)
            nodo=nodo.next

        return cursos
    def devolverCreditos(self,codigo):
        nodo=self.head
        while nodo:
            if nodo.codigo==codigo:
                return nodo.creditos
            nodo=nodo.next

    def devolverPrerequisitos(self,codigo):
        nodo=self.head
        while nodo:
            if nodo.codigo==codigo:
                return nodo.prerequisitos
            nodo=nodo.next

    def devolverNombre(self,codigo):
        nodo=self.head
        while nodo:
            if nodo.codigo==codigo:
                return nodo.nombre
            nodo=nodo.next


    def devolver(self):
        nodo=self.head
        self.lista=[]
        while nodo:
            curso={
                "codigo":nodo.codigo,
                "nombre":nodo.nombre
            }
            self.lista.append(curso)
            nodo=nodo.next
        return self.lista
        

    def devolverdata(self,codigo):
        nodo=self.head
        while nodo:
            if codigo==nodo.codigo:
                data={
                    "nombre":nodo.nombre,
                    "creditos":nodo.creditos,
                    "prerequisitos":nodo.prerequisitos,
                    "obligatorio":nodo.obligatorio
                }
                return data
            nodo=nodo.next

    def mostrar(self):
        nodo=self.head

        while nodo:
            print(nodo.codigo)
            nodo=nodo.next

