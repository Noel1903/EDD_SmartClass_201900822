from Apuntes import Tabla
from solovayStrassen import strassen
from cursosE import Curses
from cursosP import Cursos
from matrizAd import list_
from merkle_users import tree_merkle
import hashlib 



listaA=list_()
s=strassen()
tabla=Tabla()
merkle=tree_merkle()

merkle.insertar("3003939460101","08/11/2021")
merkle.insertar("2594161514846","08/11/2021")
merkle.insertar("9499661998962","08/11/2021")
merkle.insertar("1616166629763","08/11/2021")
merkle.insertar("7946330475614","09/11/2021")

a0=hashlib.sha256("300393946010108/11/2021".encode()).hexdigest()
a1=hashlib.sha256("259416151484608/11/2021".encode()).hexdigest()
a2=hashlib.sha256("949966199896208/11/2021".encode()).hexdigest()
a3=hashlib.sha256("161616662976308/11/2021".encode()).hexdigest()
h1=hashlib.sha256((a0+a1).encode()).hexdigest()
h2=hashlib.sha256((a2+a3).encode()).hexdigest()

root=hashlib.sha256((h1+h2).encode()).hexdigest()
merkle.mostrar()

print("------------")
print(root)




