from solovayStrassen import strassen
import json
stras=strassen()
class Nodo:
    def __init__(self,carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre):
        self.carnet=carnet
        self.codigo=codigo
        self.nombre=nombre
        self.creditos=creditos
        self.prerequisitos=prerequisitos
        self.obligatorio=obligatorio
        self.año=año
        self.semestre=semestre
        self.next=None


class List:
    def __init__(self):
        self.head=None
        self.body=None

    def insertar(self,carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre):
        nuevo=Nodo(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)
        if self.head==None:
            self.head=nuevo
            self.body=nuevo
        else:
            self.body.next=nuevo
            self.body=nuevo

    def vacio(self):
        if self.head==None:
            return True
        else:
            return False
    
    def carnet(self,carnet):
        if self.head!=None:
            if carnet==self.head.carnet:
                return True
        return False

    def devolverCarnet(self):
        if self.head!=None:
            return self.head.carnet
        else:
            return None

    def devolverlista(self):
        arr=[]
        nodo=self.head
        while nodo:
            data={
                "codigo":nodo.codigo,
                "nombre":nodo.nombre,
                "creditos":nodo.creditos,
                "semestre":nodo.semestre,
                "año":nodo.año
            }
            arr.append(data)
            nodo=nodo.next
        return arr
    
    def devolverDatos(self,carnet):
        if self.head!=None:
            if carnet==self.head.carnet:
                nodo=self.head
                datos=[]
                while nodo:
                    data={
                        'titulo':nodo.titulo,
                        'apunte':nodo.apunte
                    }
                    datos.append((data))
                    nodo=nodo.next
                return datos

    def mostrar(self):
        nodo=self.head
        while nodo:
            print(nodo.codigo+" - "+nodo.nombre+" - "+str(nodo.creditos))
            nodo=nodo.next
    

class Curses:
    def __init__(self):
        self.tabla=[None,None,None,None,None,None,None]
        self.size=7
        
        for i in range(0,7):
            self.tabla[i]=List()
            

        
    

    def insertar(self,carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre):
        posicion=carnet % self.size
        if posicion % 2 !=0:
            posicion+=1
        if self.cursos(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)==False:
            if self.tamaño()<=0.5:

                if self.tabla[posicion].vacio():
                    self.tabla[posicion].insertar(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)
                else:
                    posicion+=2
                    while True:
                       
                        if posicion <self.size:
                            
                            if self.tabla[posicion].vacio():
                                self.tabla[posicion].insertar(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)
                                return 

                            else:
                                posicion+=2
                        else:
                            posicion=0
            else:
                for i in range(self.size,self.sig_primo(self.size)):
                    self.tabla.append(None)
                    self.tabla[i]=List()


                self.size=len(self.tabla)
                
                posicion=carnet % self.size
                if posicion % 2 !=0:
                    posicion+=1
                if self.tabla[posicion].vacio():
                    self.tabla[posicion].insertar(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)
                else:
                    posicion+=2
                    while True:
                        
                        if posicion <self.size:
                            
                            if self.tabla[posicion].vacio():
                                self.tabla[posicion].insertar(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)
                                return
                            else:
                                posicion+=2 
                        else:
                            posicion=0
        

    def cursos(self,carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre):
        for i in self.tabla:
            if i.carnet(carnet):
                i.insertar(carnet,codigo,nombre,creditos,prerequisitos,obligatorio,año,semestre)
                return 

        return False
        
    

    def devolverCursosEstudiante(self,carnet):
        datos=[]
        for i in self.tabla:
            if i!=None:
                if carnet==i.devolverCarnet():
                    datos=i.devolverlista()
                    return datos
    
    def mostarTabla(self):
        for i in range(0,len(self.tabla)):
            print(str(i)+")")
            self.tabla[i].mostrar()
    
            

    def tamaño(self):
        cont=0
        for i in self.tabla:
            if i.vacio()!=True:
                cont+=1
        return cont/self.size

    def sig_primo(self,size):
        tamaño=stras.next_prime(int(size))
        return tamaño

    