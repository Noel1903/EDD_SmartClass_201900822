import hashlib
from datetime import datetime
class node_data:
    def __init__(self,dpi,fecha,hash,position):
        self.dpi=dpi
        self.fecha=fecha
        self.hash=hash
        self.position=position
        self.next=None

    def getDpi(self):
        return self.dpi

    def set_block(self,dpi,fecha):
        self.dpi=dpi
        self.fecha=fecha
        self.hash=hashlib.sha256((dpi+fecha).encode()).hexdigest()

    



class list_data:
    def __init__(self):
        self.head=None
        self.body=None
        self.position=0

    def data_block(self,dpi,fecha):
        hash=hashlib.sha256((dpi+fecha).encode()).hexdigest()
        nuevo=node_data(dpi,fecha,hash,self.position)

        if self.head==None:
            self.head=nuevo
            self.body=nuevo
        else:
            self.body.next=nuevo
            self.body=nuevo

        self.position+=1

    def hash_vacio(self,dpi,fecha):
        node=self.head

        while node:
            if node.getDpi()=="-1":
                node.set_block(dpi,fecha)
                return True
            node=node.next
        return False
    
    def return_hash(self,position):
        nodo=self.head
        while nodo:
            if nodo.position==position:
                return nodo.hash
            nodo=nodo.next

    def getTamaño(self):
        return self.position


    def imprimir(self):
        nodo=self.head
        while nodo:
            print(str(nodo.hash))
            nodo=nodo.next

class merkle_roots:
    def __init__(self,hash_L,hash_R,hash,position):
        self.hash_L=hash_L
        self.hash_R=hash_R
        self.hash=hash
        self.position=position
        self.next=None

    def set_root(self,hash_L,hash_R):
        self.hash_L=hash_L
        self.hash_R=hash_R
        self.hash=hashlib.sha256((hash_L+hash_R).encode()).hexdigest()

    

class list_root:
    def __init__(self):
        self.head=None
        self.body=None
        self.down=None
        self.size=0
    
    def insert(self,hash_L,hash_R):
        hash=hashlib.sha256((hash_L+hash_R).encode()).hexdigest()
        nuevo=merkle_roots(hash_L,hash_R,hash,self.size)
        if self.head==None:
            self.head=nuevo
            self.body=nuevo
        else:
            self.body.next=nuevo
            self.body=nuevo

        self.size+=1
    
    def rehash(self,position,hashL,hashR):
        nodo=self.head
        while nodo:
            if nodo.position==position:
                nodo.set_root(hashL,hashR)
            nodo=nodo.next 

    def return_hash(self,position):
        nodo=self.head
        while nodo:
            if nodo.position==position:
                return nodo.hash
            nodo=nodo.next

    def imprimir(self):
        nodo=self.head
        while nodo:
            print(str(nodo.hash)[0:5],end="->")
            nodo=nodo.next

        print("")

    def size_list(self):
        return self.size


class tree_merkle:
    def __init__(self):
        self.list=list_data()
        self.list.data_block("-1","-1")
        self.list.data_block("-1","-1")
        self.cont=0
        self.root=list_root()
        self.root.insert(self.list.return_hash(0),self.list.return_hash(1))

     

    def insertar(self,dpi,fecha):
        
        if self.list.hash_vacio(dpi,fecha)!=True:
            aumento=pow(2,self.cont)
            for i in range(aumento-self.list.getTamaño()):
                self.list.data_block("-1","-1")

            self.list.hash_vacio(dpi,fecha)

            self.insert_root(self.root)

        else:
            self.hash_root(self.root)

        self.cont+=1

    def hash_root(self,root):
        cont=0
        if root.down==None:
            for i in range(root.size_list()):
                
                if cont>self.list.getTamaño():
                    root.rehash(i,self.list.return_hash(cont),self.list.return_hash(cont+1))
                cont+=2

        else:
            for i in range(root.size_list()):
                if cont>root.down.size_list():
                    root.rehash(i,root.down.return_hash(cont),root.down.return_hash(cont+1))
                cont+=2
            self.hash_root(root.down)

    def insert_root(self,root):
        if root.down==None:
            tamaño=int(self.list.getTamaño()/2)
            
            for i in range(tamaño-root.size_list()):
                root.insert("-1","-1")
            self.hash_root(root)
        else:
            tamaño=int(root.size_list()/2)
            for i in range(tamaño-root.down.size_list()):
                root.insert("-1","-1")
            self.hash_root(root)
            self.insert_root(root.down)
        
        if int(self.root.size_list()/2)==1:
            print("Si")
            temp=list_root()
            temp.insert("-1","-1")
            temp.down=self.root
            self.root=temp
        self.hash_root(self.root)

        


    def mostrar(self):
        self.root.imprimir()
        if self.root.down!=None:
            self.mostrar01(self.root.down)
        self.list.imprimir()

    def mostrar01(self,root):
        root.imprimir()
        if root.down!=None:
            self.mostrar01(root.down)
        


    
        