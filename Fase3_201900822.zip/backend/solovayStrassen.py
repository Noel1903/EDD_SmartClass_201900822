
import sys
 
sys.setrecursionlimit(1000)

class strassen:
    def es_primo(self,n):
        pivot=2
        band=True
        while band and pivot<n:
            if n%pivot==0:
                band=False
            else:
                pivot=pivot+1
        return band
    
    def next_prime(self,num):
        while True:
            num=num+1
            if self.es_primo(num):
                return num