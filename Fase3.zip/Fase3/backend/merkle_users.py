import hashlib


class merkle_node:
    def __init__(self):
        self.left=None
        self.right=None
        self.datos=None

    
class merkle_tree:
    def __init__(self):
        self.root=None
        self.cont=0
        

    def nuevo_nodo(self,left,right,data):
        new_node=merkle_node()
        if left==None and right==None:
            hash_data=hashlib.sha256(data.encode()).hexdigest()
            new_node.datos=hash_data

        else:
            data_hash=left.datos+right.datos
            new_node.datos=hashlib.sha256(data_hash.encode()).hexdigest()


        new_node.left=left
        new_node.right=right
        return new_node


    """def insertar(self,datas):
        self.root="""
        




    def imprimir(self):
        print(self.root.datos)


    def imprimir01(self,data):
        print(data.datos)
        if data.left!=None:
            self.imprimir01(data.left)
        if data.right!=None:
            self.imprimir01(data.right)


        

        