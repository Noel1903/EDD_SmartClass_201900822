from cryptography.fernet import Fernet
import base64
from flask import Flask, json,jsonify,request
import os

from flask.globals import request
from werkzeug import datastructures

from cursosP import Cursos
from cursosE import Curses
from matrizAd import list_
from Estudiantes import estudiante
from Apuntes import Tabla
from flask_cors import CORS
listaA=list_()
curses=Cursos()
cursos_estudiante=Curses()
clave=Fernet.generate_key()

e=Fernet(clave)
app=Flask(__name__)
CORS(app)
Students=[]

apuntes=Tabla()

cont=1
@app.route('/carga',methods=['POST'])
def cargaMasiva():

    tipo=request.json["tipo"]
    tipocarga=""
    if tipo=="1":
        tipocarga="estudiantes"
        datas=request.json["texto"]["estudiantes"]
        global Students
        for data in datas:
            carnet=e.encrypt(str(data["carnet"]).encode())
            dpi=e.encrypt(str(data["DPI"]).encode())
            nombre=e.encrypt(data["nombre"].encode())
            correo=e.encrypt(data["correo"].encode())
            password=e.encrypt(data["password"].encode())
            edad=e.encrypt(str(data["edad"]).encode())
            Students.append(estudiante(carnet,dpi,nombre,data["carrera"],correo,password,edad))

    if tipo=="2":
        tipocarga="cursos pensum"
        data=request.json["texto"]["Cursos"]
        for i in data:
            curses.insertar(i["Codigo"],i["Nombre"],i["Creditos"],i["Prerequisitos"],i["Obligatorio"])


        datos=curses.devolverCursos()
        for i in datos:
            requisitos=curses.devolverPrerequisitos(i)
            nombre=curses.devolverNombre(i)
            
            for a in requisitos:
                creditos=curses.devolverCreditos(a)
            
                listaA.insert_list(i,nombre,a,creditos)
    
    if tipo=="3":
        data=request.json["texto"]["Estudiantes"]
        for i in data:
            for j in i["Años"]:
                for k in j["Semestres"]:
                    for a in k["Cursos"]:
                        cursos_estudiante.insertar(int(i["Carnet"]),a["Codigo"],a["Nombre"],a["Creditos"],a["Prerequisitos"],a["Obligatorio"],j["Año"],k["Semestre"])
    

    if tipo=="10":
        tipocarga="apuntes"
        datas=request.json["texto"]["usuarios"]
        for i in datas:
            carnet=i["carnet"]
            apunte=i["apuntes"]
            for a in apunte:
                apuntes.insertar(carnet,a["Título"],a["Contenido"])

         

    return jsonify({'mensaje':"Carga masiva "+tipocarga})


@app.route('/key',methods=['GET'])
def key():
    global clave
    return jsonify({'mensaje':clave})

@app.route('/reportehash',methods=['GET'])
def graficahash():
    apuntes.graficarApuntes()
    return jsonify({'mensaje':"Tabla Hash"})

@app.route('/apuntes',methods=['POST','GET'])
def apunte():
    if request.method=="POST":
        carnet=request.json["carnet"]
        titulo=request.json["titulo"]
        apunte=request.json["apunte"]
        apuntes.insertar(carnet,titulo,apunte)
        apuntes.mostarTabla()
        return jsonify({'mensaje':"correcto"})

    if request.method=="GET":
        return jsonify(apuntes.obtenerApuntes())



@app.route('/login',methods=['POST'])
def login():
    
    if request.method=="POST":
        print(request.json)
        
        carnet=request.json["usuario"]
        contraseña=request.json["contraseña"]
        global Students
        for i in Students:
            carn=e.decrypt(i.getCarnet()).decode()
            passw=e.decrypt(i.getPassword()).decode()
            if carn==carnet and passw==contraseña:
                return jsonify({'mensaje':"correcto"})
        return jsonify({'mensaje':"error"})

@app.route('/estudiantes',methods=['POST','GET'])
def estudiantes():
    global Students
  
    if request.method=="POST":
        carnet=request.json["carnet"]
        dpi=request.json["dpi"]
        nombre=request.json["nombre"]
        carrera=request.json["carrera"]
        correo=request.json["correo"]
        password=request.json["contraseña"]
        edad=request.json["edad"]
        #global Students
        for i in Students:
            if carnet==i.getCarnet():
                return jsonify({'mensaje':"Usuario ya registrado"})
        carnet=e.encrypt(carnet.encode())
        dpi=e.encrypt(dpi.encode())
        nombre=e.encrypt(nombre.encode())
        correo=e.encrypt(correo.encode())
        password=e.encrypt(password.encode())
        edad=e.encrypt(str(edad).encode())
        Students.append(estudiante(carnet,dpi,nombre,carrera,correo,password,edad))
        return jsonify({'mensaje':"Usuario registrado correctamente"})

    if request.method=="GET":
        grafica=""
        
        for i in range(len(Students)):
            grafica+=str(i)+"[label=\"Carnet: "+str(Students[i].getCarnet())[12:18]+"\\nDPI:"+str(Students[i].getDpi())[12:18]+"\\nNombre:"+str(Students[i].getNombre())[12:18]+"\\nCorreo:"+str(Students[i].getCorreo())[12:18]+"\\nContraseña:"+str(Students[i].getPassword())[12:18]+"\\nEdad:"+str(Students[i].getEdad())[12:18]+"\"]\n "
            if i!=len(Students)-1:
                grafica+=str(i)+"->"+str(i+1)+"\n"
        
        graficar="digraph G { rankdir=LR\n"+grafica+" }"

        documento=open("estudiantes.dot","w",encoding="utf-8")
        documento.write(graficar)
        documento.close()
        os.system("dot -Tpng estudiantes.dot -o estudiantes.png")
        os.startfile("estudiantes.png")
        return jsonify({'mensaje':"Reporte estudiantes"})


@app.route('/estudiantesD',methods=['GET'])
def reporteEs():
    grafica=""
        
    for i in range(len(Students)):
        grafica+=str(i)+"[label=\"Carnet: "+str(e.decrypt(Students[i].getCarnet()).decode())+"\\nDPI:"+str(e.decrypt(Students[i].getDpi()).decode())+"\\nNombre:"+str(e.decrypt(Students[i].getNombre()).decode())+"\\nCorreo:"+str(e.decrypt(Students[i].getCorreo()).decode())+"\\nContraseña:"+str(e.decrypt(Students[i].getPassword()).decode())+"\\nEdad:"+str(e.decrypt(Students[i].getEdad()).decode())+"\"]\n "
        if i!=len(Students)-1:
            grafica+=str(i)+"->"+str(i+1)+"\n"
    
    graficar="digraph G { rankdir=LR\n"+grafica+" }"

    documento=open("estudiantesD.dot","w",encoding="utf-8")
    documento.write(graficar)
    documento.close()
    os.system("dot -Tpng estudiantesD.dot -o estudiantesD.png")
    os.startfile("estudiantesD.png")
    return jsonify({'mensaje':"Reporte estudiantes"})


@app.route('/cursos',methods=['GET','POST'])
def cursosPensum():
    if request.method=="GET":
        return jsonify({"cursos":curses.devolver()})
    if request.method=="POST":
        carnet=request.json["carnet"]
        datos=request.json["datos"].split(" - ")
        datas=cursos_estudiante.devolverCursosEstudiante(int(carnet))
        if datas!=None:
            for i in datas:
                if i["codigo"]==datos[0]:
                    return jsonify({'mensaje':"Este curso ya esta asignado"})

        contenido=curses.devolverdata(datos[0])
        cursos_estudiante.insertar(int(carnet),datos[0],contenido["nombre"],contenido["creditos"],contenido["prerequisitos"],contenido["obligatorio"],"2021","2")
        return jsonify({'mensaje':"Curso asignado correctamente"})
        


@app.route('/cursosEstudiantes',methods=['POST','GET'])
def cursosE():
    
    if request.method=="POST":
        user=request.json["user"]
        datos=cursos_estudiante.devolverCursosEstudiante(int(user))
        return jsonify(datos)

@app.route('/grafosEstudiante',methods=['POST'])
def grafos():
    data=request.json["codigo"]
    listaA.graficar(data)
    listaA.crearDocumento()

    return jsonify({'mensaje':"Creando grafo"})


@app.route('/grafosPensum',methods=['GET'])
def grafosP():
    listaA.graficarPensum()

    return jsonify({'mensaje':"Creando grafo"})

if __name__=="__main__":
    
    app.run(port=3000,debug=True,host='0.0.0.0')