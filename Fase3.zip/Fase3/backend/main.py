from Apuntes import Tabla
from solovayStrassen import strassen
from cursosE import Curses
from cursosP import Cursos
from matrizAd import list_
from merkle_users import merkle_tree



listaA=list_()
s=strassen()
tabla=Tabla()

merkle=merkle_tree()
"""
cursos=Cursos()
cursos.insertar("101","Matemática Básica 1",7,"",True)
cursos.insertar("039","Deportes 1",1,"",False)
cursos.insertar("796","Lenguajes Formales y de Programación",3,"770,960",True)
cursos.insertar("772","Estructuras de Datos",5,"771,796,962",True)
cursos.insertar("103","Matemática Básica 2",7,"101",True)
cursos.insertar("960","Matemática Cómputo 1",5,"103,101",True)
cursos.insertar("770","Introducción a la Programación y Computación 1",4,"103",True)


datos=cursos.devolverCursos()

for i in datos:
    requisitos=cursos.devolverPrerequisitos(i)
    for a in requisitos:
        listaA.insert_list(i,a,cursos.devolverCreditos(a))

listaA.imprimir()"""

merkle.insertar("Hola este es mi hash")
merkle.insertar("Hola este es mi hash numero 2")
merkle.insertar("Hola este es")
merkle.insertar("Hola este es mi hash numero 2")
#merkle.insertar("Hola ")
#merkle.insertar("Hola este es mi hash numero 2")
#merkle.insertar("Hola este es")
#merkle.insertar("Hola este es mi hash numero 2")
#merkle.insertar("Hola ")
#merkle.insertar("Hola este es mi hash numero 2")
#merkle.insertar("Hola este es")

merkle.imprimir()





