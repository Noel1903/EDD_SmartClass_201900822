from flask.json import jsonify
from solovayStrassen import strassen
import json,os
stras=strassen()
class Nodo:
    def __init__(self,carnet,titulo,apunte):
        self.carnet=carnet
        self.titulo=titulo
        self.apunte=apunte
        self.next=None


class List:
    def __init__(self):
        self.head=None
        self.body=None
        self.cont=0

    def insertar(self,carnet,titulo,apunte):
        nuevo=Nodo(carnet,titulo,apunte)
        if self.head==None:
            self.head=nuevo
            self.body=nuevo
        else:
            self.body.next=nuevo
            self.body=nuevo

        self.cont+=1

    def vacio(self):
        if self.head==None:
            return True
        else:
            return False

    def tamaño(self):
        return self.cont
    
    def carnet(self,carnet):
        if self.head!=None:
            if carnet==self.head.carnet:
                return True
        return False

    def devolverCarnet(self):
        if self.head!=None:
            return self.head.carnet
        else:
            return None
        

    def devolverDatos(self,carnet):
        if self.head!=None:
            if carnet==self.head.carnet:
                nodo=self.head
                datos=[]
                while nodo:
                    data={
                        'titulo':nodo.titulo,
                        'apunte':nodo.apunte
                    }
                    datos.append((data))
                    nodo=nodo.next
                return datos

    def mostrar(self):
        nodo=self.head
        while nodo:
            print(str(nodo.carnet)+"--->"+nodo.titulo+"--->"+nodo.apunte)
            nodo=nodo.next

    
class Tabla:
    def __init__(self):
        self.tabla=[None,None,None,None,None,None,None]
        self.size=7
        self.grafica=""
        
        for i in range(0,7):
            self.tabla[i]=List()
            

        
    

    def insertar(self,carnet,titulo,apunte):
        posicion=carnet % self.size
        if posicion % 2 !=0:
            posicion+=1
        if self.apuntes(carnet,titulo,apunte)==False:
            if self.tamaño()<=0.5:

                if self.tabla[posicion].vacio():
                    self.tabla[posicion].insertar(carnet,titulo,apunte)
                else:
                    posicion+=2
                    while True:
                        
                        if posicion <self.size:
                            
                            if self.tabla[posicion].vacio():
                                self.tabla[posicion].insertar(carnet,titulo,apunte)
                                return
                            else:
                                posicion+=2
                        else:
                            posicion=0
                        
            else:
                for i in range(self.size,self.sig_primo(self.size)):
                    self.tabla.append(None)
                    self.tabla[i]=List()


                self.size=len(self.tabla)
                
                posicion=carnet % self.size
                if posicion % 2 !=0:
                    posicion+=1
                if self.tabla[posicion].vacio():
                    self.tabla[posicion].insertar(carnet,titulo,apunte)
                else:
                    posicion+=2
                    while True:
                        
                        if posicion <self.size:
                            
                            if self.tabla[posicion].vacio():
                                self.tabla[posicion].insertar(carnet,titulo,apunte)
                                return
                            else:
                                posicion+=2
                        else:
                            posicion=0
        

    def apuntes(self,carnet,titulo,apunte):
        for i in self.tabla:
            if i.carnet(carnet):
                i.insertar(carnet,titulo,apunte)
                return 

        return False
        



    def mostarTabla(self):
        for i in range(0,len(self.tabla)):
            print(str(i)+")")
            self.tabla[i].mostrar()
    
            

    def tamaño(self):
        cont=0
        for i in self.tabla:
            if i.vacio()!=True:
                cont+=1
        return cont/self.size

    def sig_primo(self,size):
        tamaño=stras.next_prime(int(size))
        return tamaño

    def obtenerApuntes(self):
        objetos=[]
        for i in self.tabla:

            if i.vacio()!=True:
                print(i)
                carnet=i.devolverCarnet()
                print(carnet)
                datos=i.devolverDatos(carnet)
                dat={
                        'carnet':carnet,
                        'datos':datos
                    }
                objetos.append(dat)
        return objetos
    

    def graficarApuntes(self):
        self.grafica=""
        cont=0
        self.grafica+="Table[label=\""
        for i in range(len(self.tabla)):
            if i!=len(self.tabla)-1:
                if self.tabla[i].vacio()!=True:
                    self.grafica+="<f"+str(cont)+">"+str(self.tabla[i].devolverCarnet())+"|"
                else:
                    self.grafica+="<f"+str(cont)+">  |"
            else:
                if self.tabla[i].vacio()!=True:
                    self.grafica+="<f"+str(cont)+">"+str(self.tabla[i].devolverCarnet())+"\"]\n"
                else:
                    self.grafica+="<f"+str(cont)+"> \"]\n"

            cont+=1
        self.graficarPunteros()
        

    def graficarPunteros(self):
        punteros=""
        for i in range(len(self.tabla)):
            if self.tabla[i].vacio()!=True:
                tamaño=self.tabla[i].tamaño()
                for j in range(tamaño):
                    if j!=tamaño:
                        punteros+="node_"+str(i)+str(j)+"[label=\"Apunte"+str(j+1)+"\"]\n"
                        if j+1<=tamaño-1:
                            punteros+="node_"+str(i)+str(j)+"->node_"+str(i)+str(j+1)+"\n"
                    else:
                        punteros+="node_"+str(i)+str(j)+"[label=\"Apunte"+str(j+1)+"\"]\n"
                punteros+="Table:f"+str(i)+"->node_"+str(i)+"0;\n"


        self.grafica+=punteros
        grafica="digraph G{ rankdir = LR;\n node [shape=record];\n "+self.grafica+"} "

        documento=open("Tabla_hash.dot","w",encoding="utf-8")
        documento.write(grafica)
        documento.close()
        os.system("dot -Tjpg Tabla_hash.dot -o Tabla_hash.jpg")
        os.startfile("Tabla_hash.jpg")










                

        

    