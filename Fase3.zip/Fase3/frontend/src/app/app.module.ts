import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistroComponent } from './components/registro/registro.component';
import { LoginComponent } from './components/login/login.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { UserComponent } from './components/user/user.component';
import { HeadComponent } from './components/user/head/head.component';
import { ApuntesComponent } from './components/user/apuntes/apuntes.component';
import { NuevoComponent } from './components/user/apuntes/nuevo/nuevo.component';
import { AdminComponent } from './components/admin/admin.component';
import { NavComponent } from './components/admin/nav/nav.component';
import { CargaComponent } from './components/admin/carga/carga.component';
import {HttpClientModule } from '@angular/common/http';
import { VerComponent } from './components/user/apunte/ver/ver.component';
import { CursosComponent } from './components/user/cursos/cursos.component';
import { VercursosComponent } from './components/user/vercursos/vercursos.component';
import { ReporteComponent } from './components/user/cursos/reporte/reporte.component';
import { ReportesComponent } from './components/admin/reportes/reportes.component';

@NgModule({
  declarations: [
    AppComponent,
    RegistroComponent,
    LoginComponent,
    NavbarComponent,
    UserComponent,
    HeadComponent,
    ApuntesComponent,
    NuevoComponent,
    AdminComponent,
    NavComponent,
    CargaComponent,
    VerComponent,
    CursosComponent,
    VercursosComponent,
    ReporteComponent,
    ReportesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
