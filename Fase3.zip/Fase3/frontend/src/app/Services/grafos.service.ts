import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GrafosService {

  constructor(
    private http:HttpClient
  ) { }


  verGrafo(codigo:string){
    const data={
      "codigo":codigo
    }
    const options = {
      headers: {
       'Content-Type': 'application/json',
       'Accept': 'application/json'
      }
  };
    return this.http.post('http://localhost:3000/grafosEstudiante',JSON.stringify(data),options).toPromise();
  }

  reporteTablahash(){
    return this.http.get('http://localhost:3000/reportehash').toPromise();
  }

  reporteEstudiantes(){
    return this.http.get('http://localhost:3000/estudiantes').toPromise();
  }
  reporteEstudiantesD(){
    return this.http.get('http://localhost:3000/estudiantesD').toPromise();
  }
  reportePensum(){
    return this.http.get('http://localhost:3000/grafosPensum').toPromise(); 
  }
}
