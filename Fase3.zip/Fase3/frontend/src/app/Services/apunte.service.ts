import { Injectable ,Output} from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { EventEmitter } from "@angular/core";

@Injectable({
    providedIn:'root'
})

export class ApuntesService{

    @Output() apuntes:EventEmitter<any>=new EventEmitter();
    constructor(
        private http:HttpClient
    ){}

    crearApunte(carnet:number,titulo:string,apunte:string):Promise <any>{
        const data={
            "carnet":carnet,
            "titulo":titulo,
            "apunte":apunte
        }

        const options = {
            headers: {
             'Content-Type': 'application/json',
             'Accept': 'application/json'
            }
        };
        return this.http.post<any>('http://localhost:3000/apuntes',JSON.stringify(data),options)
        .toPromise();
    }

    verApuntes():Promise<any>{
        return this.http.get<any>('http://localhost:3000/apuntes').toPromise();
    }

   

}