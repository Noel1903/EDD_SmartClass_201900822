import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";


@Injectable({
    providedIn:'root'
})

export class LoginService{

    constructor(
        private http:HttpClient
    ){
        
    }


    verificarUsuario(usuario:string,contraseña:string):Promise <any> {
        const datos={
            'usuario':usuario,
            'contraseña':contraseña
        };
        const options = {
            headers: {
             'Content-Type': 'application/json',
             'Accept': 'application/json'
            }
        };
        return this.http.post<any>('http://localhost:3000/login',JSON.stringify(datos),options)
        .toPromise();   
     
    }
    crearUsuario(carnet:string,dpi:string,nombre:string,carrera:string,correo:string,contraseña:string,edad:number):Promise <any>{
        const datos={
            'carnet':carnet,
            'dpi':dpi,
            'nombre':nombre,
            'carrera':carrera,
            'correo':correo,
            'contraseña':contraseña,
            'edad':edad
        };
        const options = {
            headers: {
             'Content-Type': 'application/json',
             'Accept': 'application/json'
            }
        };
        return this.http.post<any>('http://localhost:3000/estudiantes',JSON.stringify(datos),options)
        .toPromise();

    }
        

   
        
    

}