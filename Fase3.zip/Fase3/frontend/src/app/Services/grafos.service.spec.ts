import { TestBed } from '@angular/core/testing';

import { GrafosService } from './grafos.service';

describe('GrafosService', () => {
  let service: GrafosService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GrafosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
