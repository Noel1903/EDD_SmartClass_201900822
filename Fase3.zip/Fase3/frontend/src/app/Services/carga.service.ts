import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
    providedIn:'root'
})

export class CargaService{
    constructor(
        private http:HttpClient
    ){
        
    }

    clave():Promise<any>{

        return this.http.get<any>('http://localhost:3000/key').toPromise();
    }

    cargaMasiva(tipo:string,texto:Object):Promise <any>{
        const datos={
            "tipo":tipo,
            "texto":texto
        }
        const options = {
            headers: {
             'Content-Type': 'application/json',
             'Accept': 'application/json'
            }
        };
        return this.http.post<any>('http://localhost:3000/carga',JSON.stringify(datos),options)
        .toPromise();
    }
}