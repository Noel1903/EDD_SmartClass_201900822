import { Injectable ,Output} from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { EventEmitter } from "@angular/core";

@Injectable({
    providedIn:'root'
})

export class CursosService{
    @Output() cursos:EventEmitter<any>=new EventEmitter();
    data:EventEmitter<any>=new EventEmitter();
    constructor(
        private http:HttpClient
    ){

    }

    verCursos():Promise <any>{
        return this.http.get<any>('http://localhost:3000/cursos').toPromise();
        
    }
    verAsignados(user:string){
        const data={
            "user":user
          }
          const options = {
            headers: {
             'Content-Type': 'application/json',
             'Accept': 'application/json'
            }
        };

        return this.http.post('http://localhost:3000/cursosEstudiantes',JSON.stringify(data),options).toPromise();
    }
    asignar(user:string,datos:string):Promise<any>{
        const data={
            "carnet":user,
            "datos":datos
          }
          const options = {
            headers: {
             'Content-Type': 'application/json',
             'Accept': 'application/json'
            }
        };

        return this.http.post<any>('http://localhost:3000/cursos',JSON.stringify(data),options).toPromise();
    }


}