import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {RegistroComponent} from './components/registro/registro.component'
import {LoginComponent} from './components/login/login.component'
import {UserComponent} from './components/user/user.component'
import { ApuntesComponent } from './components/user/apuntes/apuntes.component';
import { NuevoComponent } from './components/user/apuntes/nuevo/nuevo.component';
import { AdminComponent } from './components/admin/admin.component';
import { CargaComponent } from './components/admin/carga/carga.component';
import { VerComponent } from './components/user/apunte/ver/ver.component';
import { CursosComponent } from './components/user/cursos/cursos.component';
import { ReportesComponent } from './components/admin/reportes/reportes.component';
import { VercursosComponent } from './components/user/vercursos/vercursos.component';
const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'registro',component: RegistroComponent},
  {path:'user',component:UserComponent},
  {path:'',redirectTo:'login',pathMatch:'full'},
  {path:'user/apuntes',component:ApuntesComponent},
  {path:'user/apuntes/nuevo',component:NuevoComponent},
  {path:'user/apuntes/ver',component:VerComponent},
  {path:'admin',component:AdminComponent},
  {path:'user/cursos',component:CursosComponent},
  {path:'user/cursos/table',component:VercursosComponent},
  {path:'admin/reportes',component:ReportesComponent},
  {path:'admin/carga',component:CargaComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
