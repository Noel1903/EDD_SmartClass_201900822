import { Component, OnInit,EventEmitter, Output } from '@angular/core';
import { LoginService } from 'src/app/Services/login.service';
import { Router } from '@angular/router';
import { NavComponent } from '../admin/nav/nav.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  constructor(
    private LoginService : LoginService,
    private router:Router
  ) { }

  ngOnInit(): void {
  }
      public async verificarUsuario(usuario:string,contraseña:string){
        if(usuario=="admin" && contraseña=="admin"){
            sessionStorage.setItem("user",usuario)
              this.router.navigate(['/admin']);
        }
        else{
          this.LoginService.verificarUsuario(usuario,contraseña).then(
            mensaje=>{
              if (mensaje["mensaje"]=='correcto'){
                alert(`Bienvenido ${usuario}`)
                sessionStorage.setItem("user",usuario)
                this.router.navigate(['/user']);
                
                  
              }else{
                alert(`Usuario no registrado`)
              }
            }
          ).catch(
            (e)=>{
              console.log(e)
              alert("Ha ocurrido un error")
            }
          )
          
        }
        

        }
      
    

}
