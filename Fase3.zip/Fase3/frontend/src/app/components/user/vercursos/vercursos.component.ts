import { Component, OnInit } from '@angular/core';
import { CursosService } from 'src/app/Services/cursos.service';
@Component({
  selector: 'app-vercursos',
  templateUrl: './vercursos.component.html',
  styleUrls: ['./vercursos.component.css']
})
export class VercursosComponent implements OnInit {
  cursos:object=[]
  constructor(
    private Cursos:CursosService

  ) { }

  ngOnInit( ): void {
    this.Cursos.data.subscribe(response=>{
      
      this.cursos=response

    })
  }

}
