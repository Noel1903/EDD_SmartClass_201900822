import { Component, OnInit } from '@angular/core';
import { ApuntesService } from 'src/app/Services/apunte.service';

@Component({
  selector: 'app-nuevo',
  templateUrl: './nuevo.component.html',
  styleUrls: ['./nuevo.component.css']
})
export class NuevoComponent implements OnInit {
  usuario:string="";
  constructor(
    private apunteService: ApuntesService
  ) { }

  ngOnInit(): void {
    this.usuario=sessionStorage.user
  }
  public async nuevoApunte(carnet:string,titulo:string,apunte:string){
    this.apunteService.crearApunte(parseInt(carnet),titulo,apunte).then(response=>{
      console.log(response)
      alert('Apunte creado')
    })

  }

}
