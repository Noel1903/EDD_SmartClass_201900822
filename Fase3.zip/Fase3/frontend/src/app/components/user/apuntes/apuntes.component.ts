import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apuntes',
  templateUrl: './apuntes.component.html',
  styleUrls: ['./apuntes.component.css']
})
export class ApuntesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
