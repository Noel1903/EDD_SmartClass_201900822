
import { Component, EventEmitter, OnInit, Output } from '@angular/core';

import { ApuntesService } from 'src/app/Services/apunte.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-head',
  templateUrl: './head.component.html',
  styleUrls: ['./head.component.css']
})
export class HeadComponent implements OnInit {
  usuario:string="";
  
 

  constructor(
    private ApunteService: ApuntesService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.usuario=sessionStorage.user
  }

  public async verApuntes(){
    this.ApunteService.verApuntes().then(response=>
      {
        for(var i in response){
          if(this.usuario==(response[i].carnet).toString()){

            this.ApunteService.apuntes.emit(response[i].datos)

          }
          

          
        }
      }
    )
  }

}
