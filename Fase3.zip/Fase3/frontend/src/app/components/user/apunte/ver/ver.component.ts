import { Component, Input, OnInit, Output } from '@angular/core';
import { ApuntesService } from 'src/app/Services/apunte.service';

@Component({
  selector: 'app-ver',
  templateUrl: './ver.component.html',
  styleUrls: ['./ver.component.css']
})
export class VerComponent implements OnInit {
  apuntes:object=[]

  constructor(
    private ServiceApunte:ApuntesService
  ) { }
    
  ngOnInit(): void {
    this.ServiceApunte.apuntes.subscribe(data=>{
      console.log(data)
      this.apuntes=data
    })
  }

}
