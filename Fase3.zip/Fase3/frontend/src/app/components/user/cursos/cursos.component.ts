import { Component, OnInit } from '@angular/core';
import { CursosService } from 'src/app/Services/cursos.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {
  usuario:string="";
  cursosAsignar:object=[]
  constructor(
    private CursosService:CursosService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.usuario=sessionStorage.user
    this.CursosService.cursos.subscribe(data=>{
      this.cursosAsignar=data
    })
  }

  public async asignar(){
    var opcion=document.getElementById("opcion") as HTMLSelectElement;
    console.log(opcion.options[opcion.selectedIndex].text)
    const option=opcion.options[opcion.selectedIndex].text
    this.CursosService.asignar(this.usuario,option).then(response=>{
      alert(response["mensaje"])
    })
    
  }
  

}
