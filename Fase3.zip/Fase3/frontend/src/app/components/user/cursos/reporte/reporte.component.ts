import { Component, OnInit } from '@angular/core';
import { GrafosService } from 'src/app/Services/grafos.service';
@Component({
  selector: 'app-reporte',
  templateUrl: './reporte.component.html',
  styleUrls: ['./reporte.component.css']
})
export class ReporteComponent implements OnInit {

  constructor(
    private grafos:GrafosService
  ) { }

  ngOnInit(): void {
  }

  public async vergrafo(curso:string){
    this.grafos.verGrafo(curso).then(response=>{
      console.log(response)
    })
    
    

  }

}
