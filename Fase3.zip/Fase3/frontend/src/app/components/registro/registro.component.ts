import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/Services/login.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  constructor(
    private LoginService : LoginService,
    private router:Router
  ) { }

  ngOnInit(): void {
  }

  public async registro(carnet:string,dpi:string,nombre:string,carrera:string,correo:string,contraseña:string,edad:string){
    this.LoginService.crearUsuario(carnet,dpi,nombre,carrera,correo,contraseña,parseInt(edad)).then(
      mensaje=>{
        alert(mensaje["mensaje"])
        this.router.navigate(["/login"])
      }
    )

  }

}
