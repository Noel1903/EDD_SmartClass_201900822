import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CursosService } from 'src/app/Services/cursos.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  usuario:string="";
  constructor(
    private router:Router,
    private CursosService:CursosService
  ) { }

  ngOnInit(): void {
    this.usuario=sessionStorage.user
  }
  loggout(){
    alert("Cerrando sesión")
    sessionStorage.removeItem("usuario")
    this.router.navigate(['/login'])
  }
  public async cursos(){

    this.CursosService.verCursos().then(response=>{
      this.CursosService.cursos.emit(response["cursos"])
    })

    this.verAsignados()

  }
  public async verAsignados(){
    this.CursosService.verAsignados(this.usuario).then(response=>{
      this.CursosService.data.emit(response)
    })
  }

}
