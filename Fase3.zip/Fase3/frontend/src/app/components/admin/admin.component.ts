import { Component, OnInit,Input} from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  @Input() usuario:string="";
  constructor(
    
  ) { }

  ngOnInit(): void {
  }

}
