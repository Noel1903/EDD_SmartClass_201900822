import { Component, OnInit } from '@angular/core';

import { GrafosService } from 'src/app/Services/grafos.service';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.component.html',
  styleUrls: ['./reportes.component.css']
})
export class ReportesComponent implements OnInit {
  ruta :string=""
  constructor(
    private Reportes:GrafosService
  ) { }

  ngOnInit(): void {
    
   }

  reporteTabla(){
    this.Reportes.reporteTablahash().then(response=>{
      console.log(response)

    this.ruta="../../../../../../Tabla_hash.jpg"

    })
  }
  reporteEstudiantes(){
    this.Reportes.reporteEstudiantes().then(response=>{
      console.log(response)
    })

    

  
  }
  

  reportePensum(){
    this.Reportes.reportePensum().then(response=>{
      console.log(response)
    })
  }

  reporteEstudiantesD(){
    this.Reportes.reporteEstudiantesD().then(response=>{
      console.log(response)
    })
  }

}
