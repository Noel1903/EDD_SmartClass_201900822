
import { Component, OnInit } from '@angular/core';
import { CargaService } from 'src/app/Services/carga.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-carga',
  templateUrl: './carga.component.html',
  styleUrls: ['./carga.component.css']
})
export class CargaComponent implements OnInit {
  key:string="";
  constructor(
    private Cargaservice : CargaService,
    private router:Router
  ) { }

  ngOnInit(): void {
    
    
  }
  
  public async enviarArchivo(){
    const texto=document.getElementById("texto") as HTMLTextAreaElement ;
    const option=document.getElementById("op") as HTMLSelectElement;
    console.log(texto.value)
    console.log(option.value)
    var datos=JSON.parse(texto.value)
    this.Cargaservice.cargaMasiva(option.value,datos).then(response=>
      {
        console.log(response);
        alert(response["mensaje"])
        texto.value=""
        
      }
    )
  }
  

}
