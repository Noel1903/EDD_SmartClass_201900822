import { Component, OnInit,Input} from '@angular/core';
import { Router } from '@angular/router';
import { CargaService } from 'src/app/Services/carga.service';
export const AUTH_KEY_TOKEN='auth-token';
@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  usuario:string="";
  
  constructor(
    private router:Router
  ) {
    
   }

  ngOnInit(): void {
    this.usuario=sessionStorage.admin

  }
  loggout(){
    alert("Cerrando sesión")
    sessionStorage.removeItem("admin")
    this.router.navigate(['/login'])
  }


}
